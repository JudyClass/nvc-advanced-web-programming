<?php 
	$cat ="Mr. Jingles"
?>

<html>
	<head>
		<title>Assignment Stuffs</title>
	</head>
	<body>
		<h1>Hey Rudith!</h1>
		<p>Woooo! Extra points for responsive images! No?!</p>
		<p>This is a variable coming up! Ahem: <?php echo $cat; ?> is a cat!</p>
		<img style="max-width: 100%;" src="img/screenshot.png" />
	</body>
</html>